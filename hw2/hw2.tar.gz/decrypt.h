void decrypt(char*);
void decryptKey();
