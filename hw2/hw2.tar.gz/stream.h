void stream(char *, int, unsigned char[]);
