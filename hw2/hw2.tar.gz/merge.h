void merge(char*, char*);
