void encrypt(char* , char* , char*, char * );
void encryptKey(char*, char*, char*);
int isDigit(char *);
