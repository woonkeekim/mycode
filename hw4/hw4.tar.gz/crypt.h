void cryptFromKey(char *);
void crypt(char *, char* );

