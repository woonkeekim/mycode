void invkey(char *);
