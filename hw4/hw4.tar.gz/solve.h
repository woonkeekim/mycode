void solve(int, char *);

