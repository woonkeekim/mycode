void sortResult(int[][2] );
void histoFromKey(int, int);
void histo(int, int, char*);

