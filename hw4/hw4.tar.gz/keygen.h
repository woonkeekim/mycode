void stream(char *, int, unsigned char);
void keygen(char *, int );
